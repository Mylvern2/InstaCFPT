import { mongoDataSource } from 'src/main'
import { User } from 'src/models/user.model'

export class UserService {
  async getUsers(): Promise<User[]> {
    // const userRepo = mongoDataSource.getRepository(User)
    const userRepo = mongoDataSource.getRepository(User)
    console.log('service : getUsers()')
    console.log('userRepo.find() :', userRepo.find())
    return userRepo.find()
  }

  async addUser(name: string): Promise<User> {
    const userRepo = mongoDataSource.getRepository(User)
    let user = new User()
    user.name = name
    return userRepo.save(user)
  }
}

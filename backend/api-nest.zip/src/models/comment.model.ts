import { Entity, ObjectIdColumn, Column } from 'typeorm'
import { ObjectId } from 'mongodb'

@Entity()
export class Comment {
  @ObjectIdColumn()
  _id: ObjectId 
  @Column()
  author: ObjectId 
  @Column()
  text: string
}
